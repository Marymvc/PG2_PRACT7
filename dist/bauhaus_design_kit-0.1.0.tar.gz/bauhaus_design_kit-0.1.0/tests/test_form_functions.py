import pytest
import sys
import os

# Agregar src al path para importar los módulos
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from bauhaus_design_kit import FormFunctionOptimizer

def test_optimize_living_room():
    optimizer = FormFunctionOptimizer()
    result = optimizer.optimize_volume_for_function('living_room', {})
    
    assert result['width'] > 0
    assert result['depth'] > 0
    assert result['height'] == 2.7
    assert result['window_area'] == 6.0  # 20 * 0.3

def test_invalid_space_type():
    optimizer = FormFunctionOptimizer()
    with pytest.raises(ValueError):
        optimizer.optimize_volume_for_function('invalid_space', {})