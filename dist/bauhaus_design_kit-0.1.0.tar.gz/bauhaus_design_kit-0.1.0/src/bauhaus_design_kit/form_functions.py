class FormFunctionOptimizer:
    def __init__(self):
        self.function_profiles = {
            'living_room': {'min_area': 20, 'window_ratio': 0.3, 'ceiling_height': 2.7},
            'bedroom': {'min_area': 12, 'window_ratio': 0.2, 'ceiling_height': 2.4},
            'kitchen': {'min_area': 8, 'window_ratio': 0.25, 'ceiling_height': 2.4},
            'bathroom': {'min_area': 4, 'window_ratio': 0.1, 'ceiling_height': 2.4},
            'studio': {'min_area': 15, 'window_ratio': 0.4, 'ceiling_height': 3.0}
        }
    
    def optimize_volume_for_function(self, space_type, requirements):
        if space_type not in self.function_profiles:
            raise ValueError(f"Tipo de espacio '{space_type}' no soportado")
        
        base_profile = self.function_profiles[space_type].copy()
        base_profile.update(requirements)
        
        return self._calculate_optimal_dimensions(base_profile)
    
    def _calculate_optimal_dimensions(self, profile):
        area = profile['min_area']
        height = profile['ceiling_height']
        
        width = (area * 1.618) ** 0.5
        depth = area / width
        
        return {
            'width': round(width, 2),
            'depth': round(depth, 2),
            'height': height,
            'window_area': round(area * profile['window_ratio'], 2),
            'area': area
        }