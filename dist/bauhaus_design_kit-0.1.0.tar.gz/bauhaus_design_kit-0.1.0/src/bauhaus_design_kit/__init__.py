"""
BauhausDesignKit - Librería inspirada en principios Bauhaus para diseño arquitectónico
"""

from .form_functions import FormFunctionOptimizer
from .color_theory import KandinskyColorTheory
from .spatial_geometry import BauhausGeometry
from .revit_integration import RevitBauhausDesign

__version__ = "0.1.0"
__author__ = "Tu Nombre"
__all__ = [
    'FormFunctionOptimizer',
    'KandinskyColorTheory', 
    'BauhausGeometry',
    'RevitBauhausDesign'
]